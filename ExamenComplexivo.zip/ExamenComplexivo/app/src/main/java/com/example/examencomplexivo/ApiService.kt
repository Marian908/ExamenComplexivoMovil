package com.example.examencomplexivo

// ApiService.kt
import retrofit2.Retrofit
import retrofit2.converter.gson.GsonConverterFactory
import retrofit2.http.GET

// Define la URL base de tu servidor
private const val BASE_URL = "http://172.0.1.160:8080/productos/"

interface ApiService {
    @GET("productos")
    suspend fun getProductos(): List<Producto>
}

object RetrofitClient {
    val apiService: ApiService by lazy {
        Retrofit.Builder()
            .baseUrl(BASE_URL)
            .addConverterFactory(GsonConverterFactory.create())
            .build()
            .create(ApiService::class.java)
    }
}
