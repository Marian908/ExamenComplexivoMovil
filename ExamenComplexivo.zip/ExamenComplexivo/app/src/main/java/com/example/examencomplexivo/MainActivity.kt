package com.example.examencomplexivo

import android.os.Bundle
import android.widget.ListView
import androidx.activity.ComponentActivity
import androidx.activity.viewModels

class MainActivity : ComponentActivity() {
    private val productoViewModel: ProductoViewModel by viewModels()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        val listView: ListView = findViewById(R.id.listView)

        productoViewModel.productos.observe(this) { productos ->
            listView.adapter = ProductoAdapter(this, productos)
        }

        // Cargar los productos
        productoViewModel.loadProductos()
    }
}