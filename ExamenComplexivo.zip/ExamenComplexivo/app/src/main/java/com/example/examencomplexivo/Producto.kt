package com.example.examencomplexivo

import com.google.gson.annotations.SerializedName

data class Producto(
    @SerializedName("id") val id: Long,
    @SerializedName("nombre") val nombre: String,
    @SerializedName("categoria") val categoria: String,
    @SerializedName("cantidad") val cantidad: String,
    @SerializedName("precio") val precio: Double, // Cambiado a Double para manejar precios decimales
    @SerializedName("ubicacion") val ubicacion: String
)
