package com.example.examencomplexivo

import android.content.Context
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ArrayAdapter
import android.widget.TextView

class ProductoAdapter(context: Context, private val productos: List<Producto>) : ArrayAdapter<Producto>(context, 0, productos) {

    override fun getView(position: Int, convertView: View?, parent: ViewGroup): View {
        val producto = getItem(position)
        val view = convertView ?: LayoutInflater.from(context).inflate(R.layout.item_producto, parent, false)

        val textNombre = view.findViewById<TextView>(R.id.textNombre)
        val textCategoria = view.findViewById<TextView>(R.id.textCategoria)
        val textCantidad = view.findViewById<TextView>(R.id.textCantidad)
        val textPrecio = view.findViewById<TextView>(R.id.textPrecio)
        val textUbicacion = view.findViewById<TextView>(R.id.textUbicacion)

        textNombre.text = producto?.nombre
        textCategoria.text = "Categoría: ${producto?.categoria}"
        textCantidad.text = "Cantidad: ${producto?.cantidad}"
        textPrecio.text = "Precio: ${producto?.precio}"
        textUbicacion.text = "Ubicación: ${producto?.ubicacion}"

        return view
    }
}